<!DOCTYPE html>
<html>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js">
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.13/angular.min.js">	
</script>
<head>
	<title>Ang Silks</title>
</head>
<body>
<div ng-app="myApp" ng-controller="myCtrl">
	<h1 align="center"><font color="#009933">Ang Silks Men Women Child All</font></h1>
	<p><B><font color="#336600">Please Select your Category :</font></B></p>
	<select ng-model="MyData" class="dropdown">
	    <option disabled selected value>-- Select your Category --</option>
	    <option>ALL</option>
	    <option>Men</option>
	    <option>Women</option>
	    <option>Children</option>
	</select><br><br>
	<button ng-click="showPopup()" class="subtn">Submit</button>
	<br>
	<br><br>
	<table id="Category">
		<tr>
			
			<th>Category</th>
			<th>Product Code</th>
			<th>Product Name</th>
			<th>Price</th>
			<th>Status</th>
			<th>Stock</th>
			<th>Images</th>
			<th>Edit</th>
			<th>Delete</th>
		</tr>

		<tr ng-repeat="x in ID">
			<td>{{x.Category}}</td>
			<td>{{x.ID}}</td>
			<td>{{x.Name}}</td>
			<td>{{x.Price}}</td>
			<td>{{x.status}}</td>
			<td>{{x.stock}}</td>
			<td><a target="_blank" href="<?php echo base_url().'/images/' ?>{{x.ID}}.jpg"><button>See Image!</button></td>
			<td ng-click="edit(x)"><button> Click !</button></td>
			<td ng-click="delete(x)"><button> Click !</button></td>
		</tr>
	</table>
	<br><br><br><br>
	<h3>Edit/Add !</h3>

<div>
	<p id="demo"></p>
	<label>Product Code</label>
    <input type="text" id="id" ng-model="id" disabled> <br><br>
    <label>Product Name</label>
    <input type="text" id="Name" ng-model="Name"><br><br>
    <label>Product Price</label>
	<input type="text" id="Price" ng-model="Price"><br><br>
	<label>Product Status</label>
	<input type="text" id="status" ng-model="status"><br><br>
	<label>Product Stock</label>
	<input type="text" id="stock" ng-model="stock"><br><br>
	<label>Product Category</label>
	<select id="Cate" ng-model="Category">
	  <option value="Men">Men</option>
	  <option value="Women">Women</option>
	  <option value="Children">Children</option>
	</select>

    <input type="submit" value="Add / Modify" ng-click="Editdata()">
</div>	
</div>
</body>
</html>
<script>
var app = angular.module("myApp", []);
app.controller("myCtrl", function($scope,$http,$window) {

$scope.delete = function(x) {

		var deletearray=x;

	$http({
    method: 'POST',
    url: 'Ang_DashBoard/delete',
    data: deletearray,
    headers: {'Content-Type':'application/x-www-form-urlencoded'}
	
	}).then(function (response) {
    	// console.log(response.data);
	    alert(response.data);
	    $window.location.reload();
	});

}

$scope.Editdata=function(){

var edit_id=document.getElementById("id").value
var edit_Name=document.getElementById("Name").value
var edit_Price=document.getElementById("Price").value
var edit_status=document.getElementById("status").value
var edit_stock=document.getElementById("stock").value
var Edata_Category=$scope.Category
if (Edata_Category == undefined || edit_Name == ""|| edit_Price == ""|| edit_Name == ""|| edit_status == ""|| edit_stock == "") {
	alert("Please Select Category or Fill All Data");
}else{

	 	$http({
    method: 'POST',
    url: 'Ang_DashBoard/Edit_data',
    data: {'Eid':edit_id,'EName':edit_Name,'EPrice':edit_Price,'cat':Edata_Category,'status':edit_status,'stock':edit_stock},
    headers: {'Content-Type':'application/x-www-form-urlencoded'}
	
	}).then(function (response) {
    
	    alert(response.data);
	    $window.location.reload();
	});

}
};


$scope.edit = function(x) {

	var edit_data=x;

	document.getElementById("Cate").setAttribute('value',edit_data.Category);
	document.getElementById("id").setAttribute('value',edit_data.ID);
	document.getElementById("Name").setAttribute('value',edit_data.Name);
	document.getElementById("Price").setAttribute('value',edit_data.Price);
	document.getElementById("status").setAttribute('value',edit_data.status);
	document.getElementById("stock").setAttribute('value',edit_data.stock);
 
};

$http({
    method : "GET",
    url : "Ang_DashBoard/LoadProduct"
  }).then(function mySuccess(response) {
  		
  		$scope.ID=response.data;
    });


$scope.showPopup=function(){
  var Category=$scope.MyData

$http({
    method: 'POST',
    url: 'Ang_DashBoard/Get_Category_All',
    data: Category,
    headers: {'Content-Type':'application/x-www-form-urlencoded'}
	
	}).then(function (response) {
    $scope.ID=response.data;
    
});  
  
};
 
});	
</script>

<style>
	
	.dropdown{
		color: #660033;
		background-color: #d1d1c2;
		padding: 5px;
		width: 200px;
		height: 40px;
		border-radius: 10px;
	}

	.subtn{
		color: #660033;
		background-color: #d1d1c2;
		padding: 2px;
		width: 80px;
		height: 30px;
		border-radius: 2px;
	}

	#Category {
	  font-family: Arial, Helvetica, sans-serif;
	  border-collapse: collapse;
	  width: 100%;
	}

	#Category td, #Category th {
	  border: 1px solid #ddd;
	  padding: 8px;
	}

	#Category tr:nth-child(even){background-color: #f2f2f2;}

	#Category tr:hover {background-color: #ddd;}

	#Category th {
	  padding-top: 12px;
	  padding-bottom: 12px;
	  text-align: left;
	  background-color: #04AA6D;
	  color: white;
	}


input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;

}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
	
</style>