<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ang_DashBoard extends CI_Controller {


	public function index()
	{
		$this->load->view('Ang_Dashboard_view');
	}

	function LoadProduct()
	{
			
			$this->load->model('Ang_Dashboard_model');
			$Data=$this->Ang_Dashboard_model->Get_Category();
			print_r($Data);
			
	}

	function Get_Category_All()
	{
		$Category=$_POST;
		foreach ($Category as $key => $value) {
			$CatValue=$key;
		}

		if ($CatValue=="ALL") {
			$this->load->model('Ang_Dashboard_model');
			$Data=$this->Ang_Dashboard_model->Get_Category();
			print_r($Data);
		}else{

		$this->load->model('Ang_Dashboard_model');
		$SelectData=$this->Ang_Dashboard_model->Get_selective($CatValue);
		print_r($SelectData);
		}
	}

	function Edit_data(){
		$EData=$_POST;
		foreach ($EData as $key => $value) {
			
			$Array=json_decode($key,true);
			$this->load->model('Ang_Dashboard_model');
			$arrayName = array($Array['Eid'],$Array['EName'],$Array['EPrice'],$Array['cat'],$Array['status'],$Array['stock']);
			$editMessage=$this->Ang_Dashboard_model->edit_add($arrayName);
			echo $editMessage;
			die();
			
			}


		}

		function delete()
		{
			$EData=$_POST;

			foreach ($EData as $key => $value) {
			
			$Array=json_decode($key,true);
			$this->load->model('Ang_Dashboard_model');
			$deletemessage=$this->Ang_Dashboard_model->deletetable($Array['ID']);
			echo $deletemessage;
			die();
			
			}
		}

	}
