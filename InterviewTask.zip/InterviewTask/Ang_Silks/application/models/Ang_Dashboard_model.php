<?php

class Ang_Dashboard_model extends CI_Model
{
	
	

	function Get_Category()
	{
		$query=$this->db->query("CALL select_all_cat()");
        $result = $query->result_array();
         return json_encode($result);	
	}

	function Get_selective($parm)
	{	
		$query=$this->db->query("CALL select_cat_list('".$parm."')");
        $result = $query->result_array();
        return json_encode($result);	
	}

	function edit_add($addvalue)
	{
			$Eid=$addvalue[0];
			$Ename=$addvalue[1];
			$EPrice=$addvalue[2];
			$cat=$addvalue[3];
			$Satus=$addvalue[4];
			$Stock=$addvalue[5];

			if($cat=="Men"){
				$cat="4";
			}else if ($cat=="Women") {
				$cat="1";
			}else if ($cat=="Children") {
				$cat="6";
			}

		if (empty($Eid)) {
			$query=$this->db->query("CALL insert_cat('".$cat."','".$Ename."','".$EPrice."','".$Stock."','".$Satus."')");
	        $result = $query->result();
	         return "Inserted";
		}else{
			$query=$this->db->query("CALL update_product('".$Eid."','".$Ename."','".$EPrice."','".$Stock."','".$Satus."','".$cat."')");
	        $result = $query->result();
	         return "Updated";
		}
		
		
	}

	function deletetable($delvalue)
	{
		$query=$this->db->query("CALL delete_product('".$delvalue."')");
	        $result = $query->result();
	         return "Deleted";
	}
			
}




?>